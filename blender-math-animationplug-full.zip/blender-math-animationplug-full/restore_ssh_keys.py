#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
SSH 密钥恢复脚本
此脚本可以从加密备份中恢复 SSH 密钥
注意：此脚本仅供懂得代码的人使用
"""

import os
import getpass
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64

def generate_key_from_password(password: str, salt: bytes) -> bytes:
    """从密码生成加密密钥"""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
    return key

def decrypt_file(file_path: str, password: str, output_path: str):
    """解密文件"""
    # 读取加密数据
    with open(file_path, 'rb') as file:
        data = file.read()
    
    # 提取盐和加密数据
    salt = data[:16]
    encrypted_data = data[16:]
    
    # 生成密钥
    key = generate_key_from_password(password, salt)
    fernet = Fernet(key)
    
    # 解密数据
    decrypted_data = fernet.decrypt(encrypted_data)
    
    # 保存解密数据
    with open(output_path, 'wb') as file:
        file.write(decrypted_data)

def restore_ssh_keys():
    """恢复 SSH 密钥"""
    ssh_dir = os.path.expanduser("~/.ssh")
    backup_dir = r"g:\GitHubcodecollection\blender-math-animationplug\ssh_backup"
    
    # 检查备份目录
    if not os.path.exists(backup_dir):
        print("备份目录不存在")
        return
    
    # 要恢复的文件
    files_to_restore = [
        "id_rsa",
        "id_rsa.pub",
        "config"
    ]
    
    # 获取密码
    password = getpass.getpass("请输入备份密码（仅懂得代码的人应知道此密码）: ")
    if not password:
        print("密码不能为空")
        return
    
    # 恢复文件
    for filename in files_to_restore:
        backup_path = os.path.join(backup_dir, f"{filename}.encrypted")
        restore_path = os.path.join(ssh_dir, filename)
        
        if os.path.exists(backup_path):
            try:
                decrypt_file(backup_path, password, restore_path)
                # 设置适当的文件权限（仅Windows）
                if filename == "id_rsa":
                    os.chmod(restore_path, 0o600)
                print(f"已恢复: {filename}")
            except Exception as e:
                print(f"恢复 {filename} 失败: {e}")
        else:
            print(f"备份文件不存在: {filename}")
    
    print("SSH 密钥恢复完成")
    print("请确保文件权限正确设置")

if __name__ == "__main__":
    print("SSH 密钥恢复工具")
    print("注意：此工具仅供懂得代码的人使用")
    print("")
    
    try:
        restore_ssh_keys()
    except KeyboardInterrupt:
        print("\n操作已取消")
    except Exception as e:
        print(f"发生错误: {e}")