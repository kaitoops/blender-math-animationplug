import sys
import os

def test_import():
    """测试插件导入是否正常"""
    try:
        # 添加当前目录到Python路径
        plugin_path = "g:/GitHubcodecollection/blender-math-animationplug"
        if plugin_path not in sys.path:
            sys.path.append(plugin_path)
        
        # 尝试导入插件主模块
        import __init__ as plugin
        
        print("✓ 插件主模块导入成功")
        
        # 测试注册函数
        try:
            plugin.register()
            print("✓ 插件注册函数执行成功")
            
            # 测试注销函数
            plugin.unregister()
            print("✓ 插件注销函数执行成功")
        except Exception as e:
            print(f"⚠ 插件注册/注销测试出现警告: {e}")
        
        return True
    except ImportError as e:
        print(f"✗ 导入失败: {e}")
        return False
    except Exception as e:
        print(f"✗ 测试过程中出现错误: {e}")
        return False

if __name__ == "__main__":
    print("开始测试循环导入修复...")
    success = test_import()
    
    if success:
        print("\n🎉 循环导入问题已修复！插件可以正常加载。")
    else:
        print("\n❌ 循环导入问题仍然存在，请检查代码。")