import bpy
import os
import shutil
import zipfile

def install_plugin():
    """安装插件到Blender"""
    
    # 获取插件路径
    addon_path = bpy.utils.user_resource('SCRIPTS', "addons")
    plugin_name = "blender-math-animationplug-full"
    plugin_path = os.path.join(addon_path, plugin_name)
    
    print(f"插件路径: {plugin_path}")
    
    # 如果插件目录已存在，先删除
    if os.path.exists(plugin_path):
        print("删除现有插件目录...")
        shutil.rmtree(plugin_path)
    
    # 获取当前工作目录（源代码目录）
    source_dir = os.path.dirname(os.path.abspath(__file__))
    zip_file = os.path.join(source_dir, "blender-math-animationplug-full-clean.zip")
    
    print(f"ZIP文件: {zip_file}")
    
    # 解压ZIP文件
    print("解压插件文件...")
    with zipfile.ZipFile(zip_file, 'r') as zip_ref:
        zip_ref.extractall(addon_path)
    
    print("插件安装完成!")
    
    # 尝试启用插件
    try:
        bpy.ops.preferences.addon_enable(module=plugin_name)
        print("插件已启用")
    except Exception as e:
        print(f"启用插件时出错: {e}")
        print("请手动在Blender中启用插件")

if __name__ == "__main__":
    install_plugin()