import os
import zipfile
import shutil

def package_plugin():
    """打包插件为ZIP文件，确保正确结构"""
    
    # 定义插件名称和源目录
    plugin_name = "blender-math-animationplug-full"
    source_dir = os.path.dirname(os.path.abspath(__file__))
    output_zip = os.path.join(source_dir, f"{plugin_name}-clean.zip")
    
    # 创建临时目录
    temp_dir = os.path.join(source_dir, "temp_plugin")
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)
    os.makedirs(temp_dir)
    
    # 创建插件目录结构
    plugin_dir = os.path.join(temp_dir, plugin_name)
    os.makedirs(plugin_dir)
    
    # 要包含的顶级目录和文件
    include_items = {
        'animation', 'core', 'mcp', 'objects', 'performance', 
        'render', 'tests', 'ui', 'workflow',
        '__init__.py', 'error_reporter.py', 'LICENSE', 
        'properties.py', 'README.md', 'README_en.md',
        'requirements.txt'
    }
    
    # 要排除的文件和目录
    exclude_items = {
        '.git', '__pycache__', '.gitignore', 'package_plugin.py', 
        'package_plugin_clean.py', 'blender-math-animationplug-full.zip',
        'blender-math-animationplug-full-clean.zip', 'test_fixes.py',
        'blender_test_fixes.py', 'reinstall_plugin_correctly.py',
        'FIXES_README.md', 'check_zip_structure.py', 'test_zip_extraction.py',
        'verify_zip_structure.py', 'extracted', 'test_extraction',
        'backup_ssh_keys.py', 'restore_ssh_keys.py', 'push_to_github.py',
        'GITHUB_PUSH_INSTRUCTIONS.md', 'github_blender', 'github_blender.pub',
        'github_key', 'github_key.pub', 'validate_plugin.py'
    }
    
    print(f"正在打包插件: {plugin_name}")
    print(f"源目录: {source_dir}")
    print(f"输出文件: {output_zip}")
    
    # 复制需要的文件和目录
    for item in os.listdir(source_dir):
        if item in exclude_items:
            continue
            
        source_item = os.path.join(source_dir, item)
        dest_item = os.path.join(plugin_dir, item)
        
        if os.path.isdir(source_item):
            if item in include_items:
                shutil.copytree(source_item, dest_item)
                print(f"复制目录: {item}")
        else:
            if item in include_items:
                shutil.copy2(source_item, dest_item)
                print(f"复制文件: {item}")
    
    # 创建ZIP文件
    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(temp_dir):
            for file in files:
                file_path = os.path.join(root, file)
                arc_path = os.path.relpath(file_path, temp_dir)
                zipf.write(file_path, arc_path)
                print(f"添加到ZIP: {arc_path}")
    
    # 清理临时目录
    shutil.rmtree(temp_dir)
    
    print(f"插件打包完成: {output_zip}")
    
    # 验证ZIP文件结构
    print("\n验证ZIP文件结构:")
    with zipfile.ZipFile(output_zip, 'r') as zipf:
        file_list = zipf.namelist()
        if f"{plugin_name}/__init__.py" in file_list:
            print("✓ 插件根目录结构正确")
        else:
            print("✗ 插件根目录结构不正确")
            
        # 检查关键模块是否存在
        key_modules = [
            f"{plugin_name}/animation/__init__.py",
            f"{plugin_name}/core/__init__.py",
            f"{plugin_name}/mcp/__init__.py",
            f"{plugin_name}/objects/__init__.py",
            f"{plugin_name}/performance/__init__.py",
            f"{plugin_name}/render/__init__.py",
            f"{plugin_name}/ui/__init__.py",
            f"{plugin_name}/workflow/__init__.py"
        ]
        
        for module in key_modules:
            if module in file_list:
                print(f"✓ {module} 存在")
            else:
                print(f"✗ {module} 不存在")

if __name__ == "__main__":
    package_plugin()