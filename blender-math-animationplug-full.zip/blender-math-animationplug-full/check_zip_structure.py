import zipfile
from pathlib import Path

def check_zip_structure():
    """检查zip文件结构"""
    zip_path = Path("blender-math-animationplug.zip")
    
    if not zip_path.exists():
        print("Zip文件不存在")
        return
    
    print("Zip文件结构:")
    with zipfile.ZipFile(zip_path, 'r') as zipf:
        for file_info in zipf.filelist:
            print(f"  {file_info.filename}")
            
    # 检查关键文件是否在正确位置
    with zipfile.ZipFile(zip_path, 'r') as zipf:
        files = [f.filename for f in zipf.filelist]
        
        # 检查是否存在插件根目录
        plugin_dirs = [f for f in files if f.startswith("blender-math-animationplug/") and f.endswith("/")]
        print(f"\n插件目录: {plugin_dirs}")
        
        # 检查__init__.py是否在正确位置
        init_files = [f for f in files if f == "blender-math-animationplug/__init__.py"]
        print(f"__init__.py位置: {init_files}")
        
        if init_files:
            print("✓ 结构正确: __init__.py位于插件目录内")
        else:
            print("✗ 结构错误: __init__.py不在正确位置")

if __name__ == "__main__":
    check_zip_structure()