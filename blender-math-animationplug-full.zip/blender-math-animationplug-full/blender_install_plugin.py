import bpy
import os
import shutil
import zipfile

class MATH_ANIM_OT_install_plugin(bpy.types.Operator):
    """安装插件操作符"""
    bl_idname = "math_anim.install_plugin"
    bl_label = "Install Plugin"
    
    def execute(self, context):
        try:
            # 获取插件路径
            addon_path = bpy.utils.user_resource('SCRIPTS', "addons")
            plugin_name = "blender-math-animationplug-full"
            plugin_path = os.path.join(addon_path, plugin_name)
            
            self.report({'INFO'}, f"插件路径: {plugin_path}")
            
            # 如果插件目录已存在，先删除
            if os.path.exists(plugin_path):
                self.report({'INFO'}, "删除现有插件目录...")
                shutil.rmtree(plugin_path)
            
            # 获取当前工作目录（源代码目录）
            source_dir = os.path.dirname(os.path.abspath(__file__))
            zip_file = os.path.join(source_dir, "blender-math-animationplug-full-clean.zip")
            
            self.report({'INFO'}, f"ZIP文件: {zip_file}")
            
            # 解压ZIP文件
            self.report({'INFO'}, "解压插件文件...")
            with zipfile.ZipFile(zip_file, 'r') as zip_ref:
                zip_ref.extractall(addon_path)
            
            self.report({'INFO'}, "插件安装完成!")
            
            # 尝试启用插件
            try:
                bpy.ops.preferences.addon_enable(module=plugin_name)
                self.report({'INFO'}, "插件已启用")
            except Exception as e:
                self.report({'ERROR'}, f"启用插件时出错: {e}")
                self.report({'ERROR'}, "请手动在Blender中启用插件")
                
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"安装插件时出错: {e}")
            return {'CANCELLED'}

def register():
    bpy.utils.register_class(MATH_ANIM_OT_install_plugin)

def unregister():
    bpy.utils.unregister_class(MATH_ANIM_OT_install_plugin)

if __name__ == "__main__":
    register()