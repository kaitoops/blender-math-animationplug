#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
SSH 密钥备份脚本
此脚本可以创建加密的 SSH 密钥备份
注意：此脚本仅供懂得代码的人使用
"""

import os
import zipfile
import getpass
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64

def generate_key_from_password(password: str, salt: bytes) -> bytes:
    """从密码生成加密密钥"""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
    return key

def encrypt_file(file_path: str, password: str, output_path: str):
    """加密文件"""
    # 生成随机盐
    salt = os.urandom(16)
    
    # 生成密钥
    key = generate_key_from_password(password, salt)
    fernet = Fernet(key)
    
    # 读取文件内容
    with open(file_path, 'rb') as file:
        file_data = file.read()
    
    # 加密数据
    encrypted_data = fernet.encrypt(file_data)
    
    # 保存加密数据和盐
    with open(output_path, 'wb') as file:
        file.write(salt)
        file.write(encrypted_data)

def backup_ssh_keys():
    """备份 SSH 密钥"""
    ssh_dir = os.path.expanduser("~/.ssh")
    backup_dir = r"g:\GitHubcodecollection\blender-math-animationplug\ssh_backup"
    
    # 创建备份目录
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    
    # 要备份的文件
    files_to_backup = [
        "id_rsa",
        "id_rsa.pub",
        "config"
    ]
    
    # 获取密码
    password = getpass.getpass("请输入备份密码（仅懂得代码的人应知道此密码）: ")
    if not password:
        print("密码不能为空")
        return
    
    # 确认密码
    confirm_password = getpass.getpass("请再次输入备份密码: ")
    if password != confirm_password:
        print("密码不匹配")
        return
    
    # 加密并备份文件
    for filename in files_to_backup:
        file_path = os.path.join(ssh_dir, filename)
        if os.path.exists(file_path):
            backup_path = os.path.join(backup_dir, f"{filename}.encrypted")
            try:
                encrypt_file(file_path, password, backup_path)
                print(f"已备份: {filename}")
            except Exception as e:
                print(f"备份 {filename} 失败: {e}")
        else:
            print(f"文件不存在: {filename}")
    
    print("SSH 密钥备份完成")
    print("警告：请妥善保管备份密码，丢失密码将无法恢复密钥")

if __name__ == "__main__":
    print("SSH 密钥备份工具")
    print("注意：此工具仅供懂得代码的人使用")
    print("")
    
    try:
        backup_ssh_keys()
    except KeyboardInterrupt:
        print("\n操作已取消")
    except Exception as e:
        print(f"发生错误: {e}")