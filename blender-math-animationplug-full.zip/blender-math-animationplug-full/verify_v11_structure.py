import zipfile
from pathlib import Path

def verify_v11_structure():
    """验证v11版本zip文件结构"""
    zip_path = Path("blender-math-animationplug-v11.zip")
    
    if not zip_path.exists():
        print("错误: v11版本Zip文件不存在")
        return False
    
    print("正在验证Blender插件v11版本ZIP文件结构...")
    print("=" * 50)
    
    with zipfile.ZipFile(zip_path, 'r') as zipf:
        files = [f.filename for f in zipf.filelist]
        
    # 检查是否有一个根目录
    root_dirs = set()
    for file_path in files:
        parts = file_path.split('/')
        if len(parts) > 1 and parts[0]:  # 至少有一个目录
            root_dirs.add(parts[0])
    
    print(f"根目录: {root_dirs}")
    
    if len(root_dirs) != 1:
        print("错误: ZIP文件应该只有一个根目录")
        return False
    
    plugin_dir_name = list(root_dirs)[0]
    print(f"插件目录名: {plugin_dir_name}")
    
    # 检查__init__.py是否在插件根目录下
    expected_init_path = f"{plugin_dir_name}/__init__.py"
    if expected_init_path in files:
        print(f"✓ 正确: __init__.py 位于 {expected_init_path}")
    else:
        print(f"✗ 错误: __init__.py 不在正确位置")
        return False
    
    # 检查是否有其他必需的文件和目录
    required_items = [
        f"{plugin_dir_name}/core/",
        f"{plugin_dir_name}/ui/",
        f"{plugin_dir_name}/objects/",
        f"{plugin_dir_name}/animation/",
        f"{plugin_dir_name}/render/",
        f"{plugin_dir_name}/performance/",
        f"{plugin_dir_name}/workflow/",
        f"{plugin_dir_name}/mcp/",
        f"{plugin_dir_name}/README.md",
        f"{plugin_dir_name}/LICENSE"
    ]
    
    missing_items = []
    for item in required_items:
        if not any(f.startswith(item) for f in files):
            missing_items.append(item)
    
    if missing_items:
        print("警告: 以下项目可能缺失:")
        for item in missing_items:
            print(f"  - {item}")
    else:
        print("✓ 所有必需的文件和目录都存在")
    
    print("=" * 50)
    print("v11版本结构验证完成")
    return True

if __name__ == "__main__":
    verify_v11_structure()