# Blender数学动画插件安装和测试说明

## 清理旧插件残留

在安装新版本之前，需要彻底清理旧插件的残留文件：

1. 在Blender中运行清理操作符：
   - 打开Blender
   - 按F3打开搜索菜单
   - 搜索"Cleanup Old Plugins"
   - 运行"Math Anim: Cleanup Old Plugins"操作符

2. 或者手动删除残留文件：
   - 删除以下文件（如果存在）：
     - `C:\Users\WIN10\AppData\Roaming\Blender Foundation\Blender\4.5\scripts\addons\properties.py`
     - `C:\Users\WIN10\AppData\Roaming\Blender Foundation\Blender\4.5\scripts\addons\error_reporter.py`
     - `C:\Users\WIN10\AppData\Roaming\Blender Foundation\Blender\4.5\scripts\addons\__init__.py`
     - `C:\Users\WIN10\AppData\Roaming\Blender Foundation\Blender\4.5\scripts\addons\LICENSE`
     - `C:\Users\WIN10\AppData\Roaming\Blender Foundation\Blender\4.5\scripts\addons\README.md`
     - `C:\Users\WIN10\AppData\Roaming\Blender Foundation\Blender\4.5\scripts\addons\README_en.md`
   - 删除以下目录（如果存在）：
     - `C:\Users\WIN10\AppData\Roaming\Blender Foundation\Blender\4.5\scripts\addons\blender-math-animationplug-full`
     - `C:\Users\WIN10\AppData\Roaming\Blender Foundation\Blender\4.5\scripts\addons\blender-mcp-main`
     - `C:\Users\WIN10\AppData\Roaming\Blender Foundation\Blender\4.5\scripts\addons\blender-math-animationplug`
     - `C:\Users\WIN10\AppData\Roaming\Blender Foundation\Blender\4.5\scripts\addons\blender-math-animationplug-core`
     - `C:\Users\WIN10\AppData\Roaming\Blender Foundation\Blender\4.5\scripts\addons\blender-math-animationplug-objects`

## 安装步骤

1. 在Blender中安装新版本插件：
   - 打开Blender
   - 进入 `编辑` → `偏好设置` → `插件` 选项卡
   - 点击 `安装...` 按钮
   - 选择 `blender-math-animationplug-full-clean.zip` 文件
   - 找到"Blender数学动画插件"并启用它
   - 保存用户设置

## 测试步骤

1. 重启Blender以确保插件完全加载

2. 测试属性和操作符注册：
   - 按F3打开搜索菜单
   - 搜索"Test Registration"
   - 运行"Math Anim: Test Registration"操作符
   - 查看信息区域和系统控制台的输出结果

3. 在3D视图的右侧UI面板中查找"数学动画"选项卡

4. 展开各个子面板测试功能：
   - 对象创建面板
   - 动画面板
   - 渲染与风格化面板
   - 性能优化面板
   - 工作流优化面板
   - MCP面板

## 验证修复

1. 检查是否还有以下错误：
   - "already registered as a subclass" 错误
   - "property not found" 错误
   - "Writing to ID classes in this context is not allowed" 错误

2. 如果仍有问题，请查看Blender的系统控制台输出获取更多错误信息

## 故障排除

1. 如果插件无法加载：
   - 检查Blender版本是否兼容（需要Blender 3.0或更高版本）
   - 检查插件ZIP文件是否完整
   - 查看Blender系统控制台中的错误信息

2. 如果面板无法显示：
   - 确保主面板已正确注册
   - 检查各子面板的bl_parent_id是否正确设置
   - 查看控制台是否有面板注册错误

3. 如果属性无法访问：
   - 检查属性是否在properties.py中正确注册
   - 确保属性访问路径正确（scene.math_anim_properties.*）
   - 查看控制台是否有属性注册错误

## 联系支持

如果问题仍然存在，请提供以下信息：
1. Blender版本
2. 操作系统版本
3. 完整的错误日志（从Blender系统控制台复制）
4. 插件版本信息