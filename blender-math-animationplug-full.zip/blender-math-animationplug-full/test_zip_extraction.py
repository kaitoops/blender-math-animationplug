import zipfile
import os
import shutil
from pathlib import Path

def test_zip_extraction():
    """测试解压zip文件并检查结构"""
    zip_path = Path("blender-math-animationplug.zip")
    extract_path = Path("test_extraction")
    
    # 清理之前的测试目录
    if extract_path.exists():
        shutil.rmtree(extract_path)
    
    # 创建测试目录
    extract_path.mkdir()
    
    print("正在解压ZIP文件...")
    
    with zipfile.ZipFile(zip_path, 'r') as zipf:
        zipf.extractall(extract_path)
    
    print("解压完成，检查结构...")
    
    # 检查解压后的结构
    items = list(extract_path.iterdir())
    print(f"解压根目录内容: {[item.name for item in items]}")
    
    if len(items) != 1 or not items[0].is_dir():
        print("错误: 解压后应该只有一个根目录")
        return False
    
    plugin_dir = items[0]
    print(f"插件目录: {plugin_dir.name}")
    
    # 检查插件目录内容
    plugin_contents = list(plugin_dir.iterdir())
    print(f"插件目录内容: {[item.name for item in plugin_contents]}")
    
    # 检查__init__.py是否存在
    init_file = plugin_dir / "__init__.py"
    if init_file.exists():
        print("✓ __init__.py 文件存在")
    else:
        print("✗ __init__.py 文件不存在")
        return False
    
    # 检查关键目录是否存在
    required_dirs = ["core", "ui", "objects", "animation", "render", "performance", "workflow", "mcp"]
    missing_dirs = []
    
    for dir_name in required_dirs:
        dir_path = plugin_dir / dir_name
        if not dir_path.exists():
            missing_dirs.append(dir_name)
    
    if missing_dirs:
        print(f"✗ 缺失目录: {missing_dirs}")
        return False
    else:
        print("✓ 所有必需目录都存在")
    
    print("ZIP文件结构测试通过!")
    return True

if __name__ == "__main__":
    test_zip_extraction()